#!/bin/bash

docker run -itd -p 80:3000 izzybirth/dcp-app:develop